﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        classtestEntities db = new classtestEntities();
        // GET: Home
        public ActionResult Index()
        {
            var products = db.Products.ToList();
            var categories = db.Categories.ToList();

            ViewBag.products = products;
            ViewBag.categories = categories;
            return View();
        }
        public ActionResult Getproductsbycategory(int Id)
        {
            var products = db.Products.Where(p => p.CategoryId == Id).ToList();
            var categories = db.Categories.ToList();

            ViewBag.products = products;

            ViewBag.categories = categories;
            return View("Index");

        }
        
    }
}